export default [
  {
    image: "https://source.unsplash.com/1600x900/?instagram"
  },
  {
    image: "https://source.unsplash.com/1600x900/?instagram"
  },
  {
    image: "https://source.unsplash.com/1600x900/?instagram"
  },
  {
    image: "https://source.unsplash.com/1600x900/?instagram"
  }
];
